const RECTANGLE = 'Rectangle';
const CIRCLE = 'Circle';
const TRIANGLE = 'Triangle';

const GetHTMLElement = (querry) => {
    return document.querySelector(`${querry}`)
}
const CheckEmpty = (value) => {
    return (value != '');
}
const CheckValid = (value) => {
    return (value != null && value != undefined);
}
const ShowWarning = (querry) => {
    var eleme = GetHTMLElement(querry);
    eleme.style.display = "block";
    setTimeout(() => {
        eleme.style.display = "none";
    }, 2000);
}
const CreateDivElement = (x, y, width, height, className, id = null) => {
    var elem = document.createElement('div');
    elem.classList.add(className);
    elem.style.width = `${width}px`;
    elem.style.height = `${height}px`;
    elem.style.left = `${x}px`;
    elem.style.top = `${y}px`;
    elem.style.zIndex = 9999;
    if (id != null) {
        elem.id = id;
    }
    return elem;
}
const SetMinimumValueInput = (targetQuerry, warningQuerry, minimum, func = null) => {
    return () => {
        var targetElement = GetHTMLElement(targetQuerry);
        var targetValue = targetElement.value;
        if (!CheckValid(targetValue) || targetValue < minimum) {
            targetElement.value = minimum;
            ShowWarning(warningQuerry);
        }
        if (func) {
            func();
        }
    }
}
const GetRectanglePoints = (x, y, width, height) => {
    var points = [
        { x: x, y: y },
        { x: x + width, y: y },
        { x: x, y: y + height },
        { x: x + width, y: y + height },
    ];
    return points;
}
const GetTrianglePoints = (x, y, width, height) => {
    var points = [
        { x: x, y: y },
        { x: x, y: y + height },
        { x: x + width, y: y + height },
    ];
    return points;
}
const GetPointsAfterRotation = (cx, cy, angle, points) => {
    var rotatedPoints = []
    for (var i = 0; i < points.length; i++) {
        rotatedPoints.push({
            x: parseFloat(cx + (points[i].x - cx) * Math.cos(angle) - (points[i].y - cy) * Math.sin(angle)),
            y: parseFloat(cy + (points[i].x - cx) * Math.sin(angle) + (points[i].y - cy) * Math.cos(angle))
        });
    }
    return rotatedPoints;
}
const GetRectanglePointsAfterRotation = (x, y, w, h, angle) => {
    var cx = parseFloat(x + w / 2);
    var cy = parseFloat(y + h / 2);
    angle = parseFloat(angle) * Math.PI / 180;
    return GetPointsAfterRotation(cx, cy, angle, GetRectanglePoints(parseFloat(x), parseFloat(y), parseFloat(w), parseFloat(h)));
}
const GetTrianglePointsAfterRotation = (x, y, w, h, angle) => {
    var cx = parseFloat(x + w / 3);
    var cy = parseFloat(y + 2 * h / 3);
    angle = parseFloat(angle) * Math.PI / 180;
    return GetPointsAfterRotation(cx, cy, angle, GetTrianglePoints(parseFloat(x), parseFloat(y), parseFloat(w), parseFloat(h)));
}