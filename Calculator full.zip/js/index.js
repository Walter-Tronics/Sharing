//CONSTANTS
const board = GetHTMLElement("#board");

//Variables ----
var isItemPicked = false;
var pickedItem = null;
var pickedItemType = null;
var canValidatePickedItem = false;

var increasedSizeItemsIndex = null;
var canValidateIncreasedSizeItems = false;

var sampleItems = [];
var filledItems = [];
var minWidth = 0, minHeight = 0;
var filledItemX = 0;
var filledItemY = 0;
var canFilledWithItems = false;

var itemId = 0;
var items = []; // type,x,y,width,height,html-id

var rotatedItem = null;
var canValidateRotatedItem = false;

var totalItemsArr = []; // type, name, width, height, arr-itemIDs
//End Variables ---

//Board --- Sizing ---
function setSizeBigShape() {
    var widthElement = GetHTMLElement("#widthBigShape");
    var heightElement = GetHTMLElement("#heightBigShape");
    var width = widthElement.value;
    var height = heightElement.value;

    var lastWidth = board.offsetWidth;
    var lastHeight = board.offsetHeight;

    board.style.width = `${width}px`;
    board.style.height = `${height}px`;

    if (checkBoundriesOfItems()) {
        board.style.width = `${lastWidth}px`;
        board.style.height = `${lastHeight}px`;
        widthElement.value = lastWidth;
        heightElement.value = lastHeight;
        ShowWarning("#sizeWarning");
    }
}
//End Board Sizing

//Board Colouring ---
function fillBoard() {
    var fillCB = GetHTMLElement("#fillCB");
    if (fillCB.checked) {
        if (canFilledWithItems === false) {
            sampleItems = JSON.parse(JSON.stringify(items));
            if (sampleItems.length > 0) {
                fillCB.checked = true;
                board.classList.replace("bg-gray-200", "bg-blue-200");
                GetHTMLElement("#processing").style.display = "block";

                minWidth = (sampleItems[0].type !== CIRCLE) ? sampleItems[0].width : sampleItems[0].radius;
                minHeight = (sampleItems[0].type !== CIRCLE) ? sampleItems[0].height : sampleItems[0].radius;
                for (var i = 0; i < sampleItems.length; i++) {
                    if (sampleItems[i].type !== CIRCLE) {
                        if (sampleItems[i].width < minWidth) {
                            minWidth = sampleItems[i].width;
                        }
                        if (sampleItems[i].height < minHeight) {
                            minHeight = sampleItems[i].height;
                        }
                    }
                    else {
                        if (2 * sampleItems[i].radius < minWidth) {
                            minWidth = 2 * sampleItems[i].radius;
                        }
                        if (2 * sampleItems[i].radius < minHeight) {
                            minHeight = 2 * sampleItems[i].radius;
                        }
                    }
                }

                filledItemX = Math.random() * 5;
                filledItemY = Math.random() * 5;
                filledItem = null;
                setTimeout(() => {
                    canFilledWithItems = true;
                }, 100);
            }
            else {
                fillCB.checked = false;
                ShowWarning("#fillWarning");
            }
        }
    }
    else {
        if (canFilledWithItems === false) {
            board.classList.replace("bg-blue-200", "bg-gray-200");
            for (var i = 0; i < filledItems.length; i++) {
                deleteShape(filledItems[i].id);
            }
            filledItems = [];
        }
        else {
            fillCB.checked = true;
        }
    }
}
function deleteShape(id) {
    var idx = items.findIndex(item => item.id === id);
    if (idx !== -1) {
        board.removeChild(GetHTMLElement(`#${id}`));
        items.splice(idx, 1);
    }
}
//End Board Colouring ---

//Box Drag and Drop ---
function dragBox(box) {
    return (e) => {
        if (!isItemPicked && e.target.tagName === "DIV" && !canFilledWithItems) {
            if (box === RECTANGLE) {
                var width = GetHTMLElement("#widthRectangle").value;
                var height = GetHTMLElement("#heightRectangle").value;
                var angle = GetHTMLElement("#angleRectangle").value;
                if (CheckEmpty(width) && CheckEmpty(height) && CheckEmpty(angle) && width >= 10 && height >= 10 && angle >= 0 && angle <= 360) {
                    isItemPicked = true;
                    pickedItemType = RECTANGLE;
                    pickedItem = CreateDivElement((e.pageX - (width / 2)), (e.pageY - (height / 2)), width, height, "rectangle-red");
                    pickedItem.style.transform = `rotate(${angle}deg)`;
                    document.body.appendChild(pickedItem);
                }
                else {
                    ShowWarning("#rectangleWarning");
                }
            }
            else if (box === CIRCLE) {
                var radius = GetHTMLElement("#radiusCircle").value;
                var angle = GetHTMLElement("#angleCircle").value;
                if (CheckEmpty(radius) && CheckEmpty(angle) && radius >= 10 && angle >= 0 && angle <= 360) {
                    isItemPicked = true;
                    pickedItemType = CIRCLE;
                    pickedItem = CreateDivElement((e.pageX - (radius)), (e.pageY - (radius)), radius * 2, radius * 2, "circle-red");
                    pickedItem.style.transform = `rotate(0deg)`;
                    document.body.appendChild(pickedItem);
                }
                else {
                    ShowWarning("#circleWarning");
                }
            }
            else if (box === TRIANGLE) {
                var width = GetHTMLElement("#widthTriangle").value;
                var height = GetHTMLElement("#heightTriangle").value;
                var angle = GetHTMLElement("#angleTriangle").value;
                if (CheckEmpty(width) && CheckEmpty(height) && CheckEmpty(angle) && width >= 10 && height >= 10 && angle >= 0 && angle <= 360) {
                    isItemPicked = true;
                    pickedItemType = TRIANGLE;
                    pickedItem = CreateDivElement((e.pageX - (width / 2)), (e.pageY - (height / 2)), width, height, "triangle-red");
                    pickedItem.style.transform = `rotate(${angle}deg)`;
                    pickedItem.style.transformOrigin = `33.333% 66.6666%`;
                    document.body.appendChild(pickedItem);
                }
                else {
                    ShowWarning("#triangleWarning");
                }
            }
        }
    }
}

function moveBox(e) {
    if (isItemPicked && CheckValid(pickedItem)) {
        pickedItem.style.left = `${e.pageX - pickedItem.offsetWidth / 2}px`;
        pickedItem.style.top = `${e.pageY - pickedItem.offsetHeight / 2}px`;
    }
}

function dropBox(e) {
    if (isItemPicked && CheckValid(pickedItem)) {
        pickedItem.style.left = `${board.parentNode.scrollLeft + e.pageX - (pickedItem.offsetWidth / 2) - board.offsetLeft}px`;
        pickedItem.style.top = `${board.parentNode.scrollTop + e.pageY - (pickedItem.offsetHeight / 2) - board.offsetTop}px`;
        pickedItem.classList.replace('rectangle-red', 'rectangle');
        pickedItem.classList.replace('circle-red', 'circle');
        pickedItem.classList.replace('triangle-red', 'triangle');
        document.body.removeChild(pickedItem);
        board.appendChild(pickedItem);

        itemId++;
        pickedItem.id = `item_${itemId}`;

        var rotate = pickedItem.style.transform.toString();

        var item = {
            id: `item_${itemId}`,
            type: pickedItemType,
            x: pickedItem.offsetLeft,
            y: pickedItem.offsetTop,
            angle: parseFloat(rotate.slice(7, rotate.length - 4)),
        }
        if (pickedItemType !== CIRCLE) {
            item = {
                ...item,
                width: pickedItem.offsetWidth,
                height: pickedItem.offsetHeight,
            }
        }
        else {
            item = {
                ...item,
                radius: pickedItem.offsetWidth / 2,
            }
        }
        items.push(item);

        isItemPicked = false;
        pickedItem = null;
        pickedItemType = null;

        canValidatePickedItem = true;
    }
}
//End Box Drag and Drop ---

//p5 ---
function draw() {
    if (canValidatePickedItem) {
        if (checkBoundriesOfItems() || checkCollisionOfItems()) {
            board.removeChild(GetHTMLElement(`#${items[items.length - 1].id}`));
            items.pop();
            itemId--;
        }
        else {
            addItemInTotalItemsArr(items[items.length - 1]);
            renderTotalItemsArr();
        }
        canValidatePickedItem = false;
    }
    if (canValidateIncreasedSizeItems) {
        var i = increasedSizeItemsIndex;
        if (checkBoundriesOfItems() || checkCollisionOfItems()) {
            if (totalItemsArr[i].type !== CIRCLE) {
                var widthElem = GetHTMLElement(`#width_${i + 1}`);
                var heightElem = GetHTMLElement(`#height_${i + 1}`);

                //Updating ----
                widthElem.value = totalItemsArr[i].width;
                heightElem.value = totalItemsArr[i].height;
                totalItemsArr[i].itemIDs.map((itemID) => {
                    let idx = items.findIndex(item => item.id === itemID);
                    if (idx !== -1) {
                        //Now Changing ----
                        items[idx].width = parseFloat(totalItemsArr[i].width);
                        items[idx].height = parseFloat(totalItemsArr[i].height);
                    }
                });
            }
            else {
                var radiusElem = GetHTMLElement(`#radius_${i + 1}`);

                //Updating ----
                radiusElem.value = totalItemsArr[i].radius;
                totalItemsArr[i].itemIDs.map((itemID) => {
                    let idx = items.findIndex(item => item.id === itemID);
                    if (idx !== -1) {
                        //Now Changing ----
                        items[idx].radius = parseFloat(totalItemsArr[i].radius);
                    }
                });
            }

            ShowWarning(`#incrementWarning_${i + 1}`);
        }
        else {
            if (totalItemsArr[i].type !== CIRCLE) {
                var width = GetHTMLElement(`#width_${i + 1}`).value;
                var height = GetHTMLElement(`#height_${i + 1}`).value;

                //Updating ----
                totalItemsArr[i].width = parseFloat(width);
                totalItemsArr[i].height = parseFloat(height);
                totalItemsArr[i].itemIDs.map((itemID) => {
                    var itemElem = GetHTMLElement(`#${itemID}`);
                    itemElem.style.width = `${width}px`;
                    itemElem.style.height = `${height}px`;
                });
            }
            else {
                var radius = GetHTMLElement(`#radius_${i + 1}`).value;

                //Updating ----
                totalItemsArr[i].radius = radius;
                totalItemsArr[i].itemIDs.map((itemID) => {
                    var itemElem = GetHTMLElement(`#${itemID}`);
                    itemElem.style.width = `${2 * radius}px`;
                    itemElem.style.height = `${2 * radius}px`;
                });

            }
            renderTotalItemsArr();
        }

        canValidateIncreasedSizeItems = false;
    }
    if (canValidateRotatedItem) {
        if (checkBoundriesOfItems() || checkCollisionOfItems()) {
            var antiClockWise = GetHTMLElement("#antiClockRotationCB").checked;
            if (antiClockWise === false) {
                rotatedItem.angle = parseFloat(rotatedItem.angle) - 10;
                if (rotatedItem.angle < 0) {
                    rotatedItem.angle = 0;
                }
            }
            else {
                rotatedItem.angle = parseFloat(rotatedItem.angle) + 10;
                if (rotatedItem.angle > 360) {
                    rotatedItem.angle = 0;
                }
            }
        }
        else {
            if (CheckValid(rotatedItem)) {
                var itemHtml = GetHTMLElement(`#${rotatedItem.id}`);
                itemHtml.style.transform = `rotate(${rotatedItem.angle}deg)`;
                if (rotatedItem.type === TRIANGLE) {
                    itemHtml.style.transformOrigin = '33.333% 66.6666%';
                }
            }
        }
        rotatedItem = null;
        canValidateRotatedItem = false;
    }
    if (canFilledWithItems) {
        for (var i = 0; i < board.offsetWidth - minWidth; i++) {
            if (canFilledWithItems) {
                var filledItem = JSON.parse(JSON.stringify(sampleItems[Math.floor(Math.random() * sampleItems.length)]));
                filledItem.x = filledItemX;
                filledItem.y = filledItemY;
                filledItem.angle = 0;
                items.push(filledItem);

                if (checkBoundriesOfItems() || checkCollisionOfItems()) {
                    items.pop();
                }
                else {
                    var item = null;
                    if (filledItem.type !== CIRCLE) {
                        var width = filledItem.width;
                        var height = filledItem.height;
                        if (CheckValid(width) && CheckValid(height) && width >= 10 && height >= 10) {
                            item = (CreateDivElement(filledItem.x, filledItem.y, width, height, (filledItem.type === RECTANGLE) ? "rectangle" : "triangle"));
                        }
                    }
                    else {
                        var radius = filledItem.radius;
                        if (CheckValid(radius) && radius >= 10) {
                            item = (CreateDivElement((filledItem.x), (filledItem.y), 2 * radius, 2 * radius, "circle"));
                        }
                    }
                    itemId++;
                    board.appendChild(item);
                    item.id = `item_${itemId}`;
                    filledItem.id = `item_${itemId}`;
                    filledItems.push(filledItem);

                    addItemInTotalItemsArr(items[items.length - 1]);
                    renderTotalItemsArr();
                }

                filledItem = null;
                filledItemX += minWidth / 2;
                if (filledItemX >= board.offsetWidth - (minWidth)) {
                    filledItemX = Math.random() * 5;
                    filledItemY += minHeight / 2;
                    if (filledItemY >= board.offsetHeight - (minHeight)) {
                        GetHTMLElement("#processing").style.display = "none";
                        canFilledWithItems = false;
                    }
                }
            }
        }
    }
}
function checkBoundriesOfItems() {
    var isOut = false;
    items.forEach(item => {
        if (item.type === RECTANGLE) {
            var points = GetRectanglePointsAfterRotation(item.x, item.y, item.width, item.height, item.angle);
            for (var i = 0; i < points.length; i++) {
                if ((points[i].x < 0) || (points[i].y < 0) || (points[i].x > board.offsetWidth) || (points[i].y > board.offsetHeight)) {
                    isOut = true;
                }
            }
        }
        else if (item.type === CIRCLE) {
            if ((item.x < 0) || (item.y < 0) || ((item.x + 2 * item.radius) > board.offsetWidth) || ((item.y + 2 * item.radius) > board.offsetHeight)) {
                isOut = true;
            }
        }
        else if (item.type === TRIANGLE) {
            var points = GetTrianglePointsAfterRotation(item.x, item.y, item.width, item.height, item.angle);
            for (var i = 0; i < points.length; i++) {
                if ((points[i].x < 0) || (points[i].y < 0) || (points[i].x > board.offsetWidth) || (points[i].y > board.offsetHeight)) {
                    isOut = true;
                }
            }
        }
    });
    return isOut;
}
function checkCollisionOfItems() {
    var isHit = false;
    for (var i = 0; i < items.length; i++) {
        for (var j = 0; j < items.length; j++) {
            if (i !== j) {
                var item1 = items[i];
                var item2 = items[j];
                if (item1.type === RECTANGLE) {
                    var rectPoints = GetRectanglePointsAfterRotation(item1.x, item1.y, item1.width, item1.height, item1.angle);
                    var shapePoly = [createVector(rectPoints[0].x, rectPoints[0].y), createVector(rectPoints[1].x, rectPoints[1].y), createVector(rectPoints[3].x, rectPoints[3].y), createVector(rectPoints[2].x, rectPoints[2].y)];
                    if (item2.type === RECTANGLE) {
                        var rect2Points = GetRectanglePointsAfterRotation(item2.x, item2.y, item2.width, item2.height, item2.angle);
                        var poly = [createVector(rect2Points[0].x, rect2Points[0].y), createVector(rect2Points[1].x, rect2Points[1].y), createVector(rect2Points[3].x, rect2Points[3].y), createVector(rect2Points[2].x, rect2Points[2].y)];
                        isHit = collidePolyPoly(poly, shapePoly);
                        if (isHit) break;
                    }
                    else if (item2.type === CIRCLE) {
                        isHit = collideCirclePoly(item2.x + item2.radius, item2.y + item2.radius, 2 * item2.radius, shapePoly);
                        if (isHit) break;
                    }
                    else if (item2.type === TRIANGLE) {
                        var trianglePoints = GetTrianglePointsAfterRotation(item2.x, item2.y, item2.width, item2.height, item2.angle);
                        var poly = [createVector(trianglePoints[0].x, trianglePoints[0].y), createVector(trianglePoints[1].x, trianglePoints[1].y), createVector(trianglePoints[2].x, trianglePoints[2].y)];
                        isHit = collidePolyPoly(poly, shapePoly);
                        if (isHit) break;
                    }
                }
                else if (item1.type === CIRCLE) {
                    if (item2.type === RECTANGLE) {
                        var rectPoint = GetRectanglePointsAfterRotation(item2.x, item2.y, item2.width, item2.height, item2.angle);
                        var poly = [createVector(rectPoint[0].x, rectPoint[0].y), createVector(rectPoint[1].x, rectPoint[1].y), createVector(rectPoint[3].x, rectPoint[3].y), createVector(rectPoint[2].x, rectPoint[2].y)];
                        isHit = collideCirclePoly(item1.x + item1.radius, item1.y + item1.radius, 2 * item1.radius, poly);
                        if (isHit) break;
                    }
                    else if (item2.type === CIRCLE) {
                        isHit = collideCircleCircle(item1.x + item1.radius, item1.y + item1.radius, 2 * item1.radius, item2.x + item2.radius, item2.y + item2.radius, 2 * item2.radius);
                        if (isHit) break;
                    }
                    else if (item2.type === TRIANGLE) {
                        var trianglePoints = GetTrianglePointsAfterRotation(item2.x, item2.y, item2.width, item2.height, item2.angle);
                        var poly = [createVector(trianglePoints[0].x, trianglePoints[0].y), createVector(trianglePoints[1].x, trianglePoints[1].y), createVector(trianglePoints[2].x, trianglePoints[2].y)];
                        isHit = collideCirclePoly(item1.x + item1.radius, item1.y + item1.radius, 2 * item1.radius, poly);
                        if (isHit) break;
                    }
                }
                else if (item1.type === TRIANGLE) {
                    var trianglePoints = GetTrianglePointsAfterRotation(item1.x, item1.y, item1.width, item1.height, item1.angle);
                    var shapePoly = [createVector(trianglePoints[0].x, trianglePoints[0].y), createVector(trianglePoints[1].x, trianglePoints[1].y), createVector(trianglePoints[2].x, trianglePoints[2].y)];
                    if (item2.type === RECTANGLE) {
                        var rectPoints = GetRectanglePointsAfterRotation(item2.x, item2.y, item2.width, item2.height, item2.angle);
                        var poly = [createVector(rectPoints[0].x, rectPoints[0].y), createVector(rectPoints[1].x, rectPoints[1].y), createVector(rectPoints[3].x, rectPoints[3].y), createVector(rectPoints[2].x, rectPoints[2].y)];
                        isHit = collidePolyPoly(poly, shapePoly);
                        if (isHit) break;
                    }
                    else if (item2.type === CIRCLE) {
                        isHit = collideCirclePoly(item2.x + item2.radius, item2.y + item2.radius, 2 * item2.radius, shapePoly);
                        if (isHit) break;
                    }
                    else if (item2.type === TRIANGLE) {
                        var triangle2Points = GetTrianglePointsAfterRotation(item2.x, item2.y, item2.width, item2.height, item2.angle);
                        var poly = [createVector(triangle2Points[0].x, triangle2Points[0].y), createVector(triangle2Points[1].x, triangle2Points[1].y), createVector(triangle2Points[2].x, triangle2Points[2].y)];
                        isHit = collidePolyPoly(poly, shapePoly);
                        if (isHit) break;
                    }
                }
            }
        }
    };
    return isHit;
}
//end p5 ---

//Render Calcultor ---
function addItemInTotalItemsArr(item) {
    if (item !== undefined && item !== null) {
        var itemHtml = GetHTMLElement(`#${item.id}`);
        itemHtml.addEventListener('mouseenter', enterMouse);
        itemHtml.addEventListener('mousedown', downMouse);
        itemHtml.addEventListener('mouseout', outMouse);

        let index = totalItemsArr.findIndex(totalItems => (totalItems.type === item.type &&
            (
                ((totalItems.type === RECTANGLE || totalItems.type === TRIANGLE) && totalItems.width === item.width && totalItems.height === item.height)
                ||
                ((totalItems.type === CIRCLE) && totalItems.radius === item.radius)
            )
        ));

        if (index !== -1) {
            totalItemsArr[index].quantity++;
            totalItemsArr[index].itemIDs.push(item.id);
        }
        else {
            var count = 0;
            totalItemsArr.forEach(totalItems => {
                if (totalItems.type === item.type) {
                    count++;
                }
            })
            var totalItems = {
                type: item.type,
                id: (item.type === RECTANGLE) ? 1 : (item.type === CIRCLE) ? 2 : (item.type === TRIANGLE) ? 3 : 0,
                name: `${item.type} (V${count + 1})`,
                quantity: 1,
                price: 10,
                itemIDs: [item.id]
            }
            if (item.type === RECTANGLE || item.type === TRIANGLE) {
                totalItems = {
                    ...totalItems,
                    width: item.width,
                    height: item.height,
                }
            }
            else if (item.type === CIRCLE) {
                totalItems = {
                    ...totalItems,
                    radius: item.radius,
                }
            }
            totalItemsArr.push(totalItems);
        }
    }
}

function renderTotalItemsArr() {
    var totalTable = GetHTMLElement("#totalTable");
    var grandTotal = 0;

    //rendering
    totalTable.innerHTML = ''
    totalItemsArr.forEach((totalItems, i) => {
        totalTable.innerHTML += `
        <tr class="border-b">
            <td class="text-sm text-gray-500 font-medium px-2 py-4 whitespace-nowrap text-left">
                ${totalItems.id}
            </td>
            <td class="text-sm text-gray-700 font-medium px-2 py-4 whitespace-nowrap text-left">
                ${totalItems.name}
            </td>
            <td class="text-sm text-gray-700 font-medium px-2 py-4 whitespace-nowrap text-left">
                <div class="flex flex-col">
                    <div>
                        <div class="flex flex-row">
                                <div><input
                                        class="w-28 md:w-40 bg-transparent text-sm mr-1 p-1 border border-gray-300 rounded focus:outline-none focus:ring-sky-400 focus:border-sky-400"
                                        type="number" id="${(totalItems.type !== CIRCLE) ? "width" : "radius"}_${i + 1}" value="${(totalItems.type !== CIRCLE) ? totalItems.width : totalItems.radius}" placeholder="${totalItems.type !== CIRCLE ? 'Width' : 'Radius'} (mm)"></div>
                                <div>
                                ${(totalItems.type !== CIRCLE) ? `
                                    <div>    
                                        <input    
                                            class="w-28 md:w-40 bg-transparent text-sm ml-1 p-1 border border-gray-300 rounded focus:outline-none focus:ring-sky-400 focus:border-sky-400"
                                            type="number" id="height_${i + 1}" value="${(totalItems.type !== CIRCLE) ? totalItems.height : totalItems.radius}" placeholder="Height (mm)">
                                    </div>`: ``
            }
                        </div>
                    </div>
                    <div>
                        <span id="sizeWarning_${i + 1}" class="text-sm text-red-500" style="display: none;">Minimum ${(totalItems.type !== CIRCLE) ? "Size is 10 x 10" : "Radius is 10"}</span>
                        <span id="incrementWarning_${i + 1}" class="text-sm text-red-500" style="display: none;">Not able to change the size of shapes</span>
                    </div>
                </div>
            </td>
            <td class="text-sm text-gray-600 font-medium px-2 py-4 whitespace-nowrap text-left">
                <div>    
                    <input    
                        class="w-28 md:w-40 bg-transparent text-sm ml-1 p-1 border border-gray-300 rounded focus:outline-none focus:ring-sky-400 focus:border-sky-400"
                        type="number" id="price_${i + 1}" value="${totalItems.price}" placeholder="Price (USD)">
                </div>
            </td>
            <td class="text-sm text-gray-600 font-medium px-2 py-4 whitespace-nowrap text-left">
                <div class="flex">
                    <img src="./images/Shape (${totalItems.id}).png" alt="shape" class="w-10 h-10 mr-2">
                    <h2 class="text-lg py-2">
                        x ${totalItems.quantity}
                    </h2>
                </div>
            </td>
            <td class="text-sm text-gray-700 font-medium px-2 py-4 whitespace-nowrap text-left">
                ${totalItems.price * totalItems.quantity}
            </td>
        </tr>`;
        grandTotal += totalItems.price * totalItems.quantity;
    });
    totalTable.innerHTML += `
    <tr class="border-b">
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td class="text-sm text-gray-700 font-bold px-2 py-6 whitespace-nowrap text-left">
            Grand total
        </td>
        <td class="text-sm text-gray-700 font-bold px-2 py-6 whitespace-nowrap text-left">
            ${grandTotal}
        </td>
    </tr>
    `;


    //Adding Events --- Price -- width -- Height -- Radius
    for (var i = 0; i < totalItemsArr.length; i++) {
        GetHTMLElement(`#price_${i + 1}`).addEventListener("change", setPrice(`#price_${i + 1}`, i));
        if (totalItemsArr[i].type === RECTANGLE || totalItemsArr[i].type === TRIANGLE) {
            GetHTMLElement(`#width_${i + 1}`).addEventListener("change", SetMinimumValueInput(`#width_${i + 1}`, `sizeWarning_${i + 1}`, 10, setSize(i)));
            GetHTMLElement(`#height_${i + 1}`).addEventListener("change", SetMinimumValueInput(`#height_${i + 1}`, `sizeWarning_${i + 1}`, 10, setSize(i)));
        }
        else if (totalItemsArr[i].type === CIRCLE) {
            GetHTMLElement(`#radius_${i + 1}`).addEventListener("change", SetMinimumValueInput(`#radius_${i + 1}`, `sizeWarning_${i + 1}`, 10, setSize(i)));
        }
    }
}

function setPrice(querry, index) {
    return (e) => {
        var priceElem = GetHTMLElement(querry);
        totalItemsArr[index].price = priceElem.value;
        renderTotalItemsArr();
    }
}

function setSize(i) {
    return (e) => {
        if (totalItemsArr[i].type !== CIRCLE) {
            var width = GetHTMLElement(`#width_${i + 1}`).value;
            var height = GetHTMLElement(`#height_${i + 1}`).value;

            var totalItems = totalItemsArr[i];

            //Updating ----
            totalItems.itemIDs.map((itemID) => {
                let idx = items.findIndex(item => item.id === itemID);
                if (idx !== -1) {
                    //Now Changing ----
                    items[idx].width = parseFloat(width);
                    items[idx].height = parseFloat(height);
                }
            });
        }
        else {
            var radius = GetHTMLElement(`#radius_${i + 1}`).value;

            var totalItems = totalItemsArr[i];

            //Updating ----
            totalItems.itemIDs.map((itemID) => {
                let idx = items.findIndex(item => item.id === itemID);
                if (idx !== -1) {
                    //Now Changing ----
                    items[idx].radius = parseFloat(radius);
                    items[idx].x = items[idx].x - totalItemsArr[i].radius + parseFloat(radius);
                    items[idx].y = items[idx].y - totalItemsArr[i].radius + parseFloat(radius);
                }
            });
        }

        increasedSizeItemsIndex = i;
        canValidateIncreasedSizeItems = true;
    }
}
//end calculor

//Mouse
function enterMouse(e) {
    if (!isItemPicked && !canValidateIncreasedSizeItems && !canValidatePickedItem && !canFilledWithItems) {
        var targetId = e.target.id;
        if (targetId.search('item') !== -1) {
            var antiClockWise = GetHTMLElement("#antiClockRotationCB").checked;
            if (antiClockWise === true) {
                e.target.classList.add('rotateAntiClockwise');
            }
            else {
                e.target.classList.add('rotateClockwise');
            }
            var idx = items.findIndex(item => item.id === targetId);
            if (items[idx].type === RECTANGLE) {
                e.target.classList.replace('rectangle', 'rectangle-rotate');
                var point = CreateDivElement((items[idx].width / 2), (items[idx].height / 2), 5, 5, "point", "point");
                e.target.appendChild(point);
            }
            else if (items[idx].type === CIRCLE) {
                e.target.classList.replace('circle', 'circle-rotate');
                var point = CreateDivElement((items[idx].radius), (items[idx].radius), 5, 5, "point", "point");
                e.target.appendChild(point);
            }
            else if (items[idx].type === TRIANGLE) {
                e.target.classList.replace('triangle', 'triangle-rotate');
                var point = CreateDivElement((items[idx].width / 3), (2 * items[idx].height / 3), 5, 5, "point", "point");
                e.target.appendChild(point);
            }
        }
    }
}
function downMouse(e) {
    if (!CheckValid(rotatedItem) && !canValidateRotatedItem && !isItemPicked && !canValidatePickedItem && !canValidateIncreasedSizeItems && !canFilledWithItems) {
        var targetId = e.target.id;
        if (targetId.search('item') !== -1) {
            var idx = items.findIndex(item => item.id === targetId);
            var antiClockWise = GetHTMLElement("#antiClockRotationCB").checked;
            if (antiClockWise === true) {
                items[idx].angle = parseFloat(items[idx].angle) - 10;
                if (items[idx].angle < 0) {
                    items[idx].angle = 0;
                }
            }
            else {
                items[idx].angle = parseFloat(items[idx].angle) + 10;
                if (items[idx].angle > 360) {
                    items[idx].angle = 0;
                }
            }
            rotatedItem = items[idx];
            canValidateRotatedItem = true;
        }
    }
}
function outMouse(e) {
    if (!isItemPicked && !canValidateIncreasedSizeItems && !canValidatePickedItem && !canFilledWithItems) {
        var targetId = e.target.id;
        if (targetId.search('item') !== -1) {
            e.target.classList.remove('rotateClockwise');
            e.target.classList.remove('rotateAntiClockwise');
            e.target.classList.replace('rectangle-rotate', 'rectangle');
            e.target.classList.replace('circle-rotate', 'circle');
            e.target.classList.replace('triangle-rotate', 'triangle');

            var point = GetHTMLElement("#point");
            if (CheckValid(point)) {
                e.target.removeChild(point);
            }
        }
    }
}

//Export and Seal ----
function getData() {
    var data = [];
    for (var i = 0; i < totalItemsArr.length; i++) {
        if (totalItemsArr[i].type === CIRCLE) {
            data.push({ "Name": totalItemsArr[i].name, "Radius": totalItemsArr[i].radius, "Quantity": totalItemsArr[i].quantity, "Price": totalItemsArr[i].price, "Outcome": (totalItemsArr[i].price * totalItemsArr[i].quantity) });
        }
        else {
            data.push({ "Name": totalItemsArr[i].name, "Width": totalItemsArr[i].width, "Height": totalItemsArr[i].height, "Quantity": totalItemsArr[i].quantity, "Price": totalItemsArr[i].price, "Outcome": (totalItemsArr[i].price * totalItemsArr[i].quantity) });
        }
    }
    return data;
}

//Seal
function seal() {
    alert(getData());
}
//End

//Export 
async function exportExcel() {
    var data = getData();
    var workbook = XLSX.utils.book_new(),
        worksheet = XLSX.utils.json_to_sheet(data, { header: ["Name", "Radius", "Width", "Height", "Quantity", "Price", "Outcome"] });
    workbook.SheetNames.push("First");
    workbook.Sheets["First"] = worksheet;

    var xlsbin = XLSX.write(workbook, {
        bookType: "xlsx",
        type: "binary"
    });

    var buffer = new ArrayBuffer(xlsbin.length),
        array = new Uint8Array(buffer);
    for (var i = 0; i < xlsbin.length; i++) {
        array[i] = xlsbin.charCodeAt(i) & 0XFF;
    }
    var xlsblob = new Blob([buffer], { type: "application/octet-stream" });
    delete array; delete buffer; delete xlsbin;

    const fileHandle = await window.showSaveFilePicker({
        suggestedName: 'exportedData.xlsx',
        types: [{
            description: "Exported Data",
            accept: { "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [".xlsx"] }
        }]
    });
    const fileStream = await fileHandle.createWritable();

    await fileStream.write(xlsblob);
    await fileStream.close();
}
//End ----


GetHTMLElement("#widthBigShape").addEventListener("change", SetMinimumValueInput("#widthBigShape", "#widthWarning", 200, setSizeBigShape));
GetHTMLElement("#heightBigShape").addEventListener("change", SetMinimumValueInput("#heightBigShape", "#heightWarning", 200, setSizeBigShape));

GetHTMLElement("#fillCB").addEventListener("change", fillBoard);

GetHTMLElement("#widthRectangle").addEventListener("change", SetMinimumValueInput("#widthRectangle", "#rectangleWarning", 10));
GetHTMLElement("#heightRectangle").addEventListener("change", SetMinimumValueInput("#heightRectangle", "#rectangleWarning", 10));
GetHTMLElement("#radiusCircle").addEventListener("change", SetMinimumValueInput("#radiusCircle", "#circleWarning", 10));
GetHTMLElement("#widthTriangle").addEventListener("change", SetMinimumValueInput("#widthTriangle", "#triangleWarning", 10));
GetHTMLElement("#heightTriangle").addEventListener("change", SetMinimumValueInput("#heightTriangle", "#triangleWarning", 10));

GetHTMLElement("#sealBtn").addEventListener("click", seal);
GetHTMLElement("#exportBtn").addEventListener("click", exportExcel);


GetHTMLElement("#rectangleBox").addEventListener("mousedown", dragBox(RECTANGLE));
GetHTMLElement("#circleBox").addEventListener("mousedown", dragBox(CIRCLE));
GetHTMLElement("#triangleBox").addEventListener("mousedown", dragBox(TRIANGLE));

document.body.addEventListener("mousemove", moveBox);
document.body.addEventListener("mouseup", dropBox);


renderTotalItemsArr();